namespace DeskMarket.Common.ValidationConstants;

public static class CategoryValidationConstants
{
    public const int NameMinLength = 3;
    public const int NameMaxLength = 20;
}