﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
                "Server=.;Database=ProductShop;User Id=sa;Password=VeryStr0ngP@ssw0rd;";
    }
}
