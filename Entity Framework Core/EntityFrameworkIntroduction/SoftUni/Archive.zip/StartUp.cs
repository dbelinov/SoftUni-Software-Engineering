﻿using SoftUni.Data;

public class StartUp
{
    public static void Main()
    {
        SoftUniContext context = new SoftUniContext();
        Console.WriteLine(GetEmployeesFullInformation(context));
    }

    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        return String.Join(Environment.NewLine, context.Employees
            .Select(e => $"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}")
            .ToList());
    }
}