﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString 
            = @"Server=.;Database=Cadastre;User Id=sa;Password=VeryStr0ngP@ssw0rd;";
    }
}
