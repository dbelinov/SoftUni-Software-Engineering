﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString 
            = @"Server=.;Database=Trucks2;User Id=sa;Password=VeryStr0ngP@ssw0rd;";
    }
}