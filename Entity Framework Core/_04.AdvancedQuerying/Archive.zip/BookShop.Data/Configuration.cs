﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=.;Database=BookShop;User Id=sa;Password=VeryStr0ngP@ssw0rd;";
    }
}
