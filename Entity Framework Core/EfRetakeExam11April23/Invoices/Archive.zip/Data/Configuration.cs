﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString 
            = @"Server=.;Database=Invoices;User Id=sa;Password=VeryStr0ngP@ssw0rd;";
    }
}
