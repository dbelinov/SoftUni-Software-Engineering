﻿using System.Text;
using SoftUni.Data;
using SoftUni.Models;

public class StartUp
{
    public static void Main()
    {
        SoftUniContext context = new SoftUniContext();
        Console.WriteLine(GetAddressesByTown(context));
    }

    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        return String.Join(Environment.NewLine, context.Employees
            .Select(e => $"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}")
            .ToList());
    }

    public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
    {
        return String.Join(Environment.NewLine, context.Employees
            .Where(e => e.Salary > 50000)
            .OrderBy(e => e.FirstName)
            .Select(e => $"{e.FirstName} - {e.Salary:f2}"));
    }

    public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
    {
        var employees = context.Employees
            .Select(e => new
            {
                e.FirstName,
                e.LastName,
                e.Department,
                e.Salary
            })
            .Where(e => e.Department.Name == "Research and Development")
            .OrderBy(e => e.Salary)
            .ThenByDescending(e => e.FirstName);

        StringBuilder sb = new StringBuilder();
        foreach (var employee in employees)
        {
            sb.AppendLine($"{employee.FirstName} {employee.LastName} from {employee.Department.Name} - ${employee.Salary:f2}");
        }

        return sb.ToString().Trim();
    }

    public static string AddNewAddressToEmployee(SoftUniContext context)
    {
        Address address = new Address()
        {
            AddressText = "Vitoshka 15",
            TownId = 4
        };

        var nakov = context.Employees
            .FirstOrDefault(e => e.LastName == "Nakov");

        if (nakov != null)
        {
            nakov.Address = address;
            context.SaveChanges();
        }

        var employees = context.Employees
            .OrderByDescending(e => e.AddressId)
            .Take(10)
            .Select(e => e.Address.AddressText);

        return String.Join(Environment.NewLine, employees);
    }

    public static string GetEmployeesInPeriod(SoftUniContext context)
    {
        var result = context.Employees
            .Take(10)
            .Select(e => new
            {
                EmployeeNames = $"{e.FirstName} {e.LastName}",
                ManagerNames = $"{e.Manager.FirstName} {e.Manager.LastName}",
                Projects = e.EmployeesProjects
                    .Where(ep 
                        => ep.Project.StartDate.Year >= 2001
                        && ep.Project.StartDate.Year <= 2003)
                    .Select(ep => new
                    {
                        ProjectName = ep.Project.Name,
                        ep.Project.StartDate,
                        ep.Project.EndDate
                    })
            });

        StringBuilder sb = new StringBuilder();
        foreach (var ep in result)
        {
            sb.AppendLine($"{ep.EmployeeNames} - Manager: {ep.ManagerNames}");

            if (ep.Projects.Any())
            {
                foreach (var project in ep.Projects)
                {
                    string endDate = "";
                    if (project.EndDate is null)
                    {
                        endDate = "not finished";
                    }
                    else 
                    {
                        endDate = project.EndDate.ToString();
                    }
                    sb.AppendLine($"--{project.ProjectName} - {project.StartDate:M/d/yyyy h:mm:ss tt} - {endDate:M/d/yyyy h:mm:ss tt}");
                }
            }
        }

        return sb.ToString().Trim();
    }

    public static string GetAddressesByTown(SoftUniContext context)
    {
        var addresses = context.Addresses
            .OrderByDescending(a => a.Employees.Count)
            .ThenBy(a => a.Town.Name)
            .ThenBy(a => a.AddressText)
            .Take(10)
            .Select(a => new
            {
                AddressTextProp = a.AddressText,
                TownName = a.Town.Name,
                EmployeeCount = a.Employees.Count
            });

        StringBuilder sb = new StringBuilder();
        foreach (var address in addresses)
        {
            sb.AppendLine($"{address.AddressTextProp}, {address.TownName} - {address.EmployeeCount} employees");
        }

        return sb.ToString().Trim();
    }
}