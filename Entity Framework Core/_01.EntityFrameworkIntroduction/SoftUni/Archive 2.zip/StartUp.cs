﻿using SoftUni.Data;

public class StartUp
{
    public static void Main()
    {
        SoftUniContext context = new SoftUniContext();
        Console.WriteLine(GetEmployeesWithSalaryOver50000(context));
    }

    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        return String.Join(Environment.NewLine, context.Employees
            .Select(e => $"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}")
            .ToList());
    }

    public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
    {
        return String.Join(Environment.NewLine, context.Employees
            .Where(e => e.Salary > 50000)
            .OrderBy(e => e.FirstName)
            .Select(e => $"{e.FirstName} - {e.Salary:f2}"));
    }
}