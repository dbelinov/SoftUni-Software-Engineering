using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Handball.Models.Contracts;
using Handball.Utilities.Messages;

namespace Handball.Models;

public abstract class Team : ITeam
{
    private string name;
    private List<IPlayer> players;

    protected Team(string name)
    {
        Name = name;
        PointsEarned = 0;

        players = new List<IPlayer>();
    }
    
    public string Name
    {
        get => name;
        private set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException(ExceptionMessages.TeamNameNull);
            }

            name = value;
        }
    }
    public int PointsEarned { get; private set; }

    public double OverallRating
    {
        get
        {
            if (Players.Count > 0)
            {
                return Players.Average(p => p.Rating);
            }

            return 0;
        }
    }

    public IReadOnlyCollection<IPlayer> Players => players.AsReadOnly();

    public void SignContract(IPlayer player) => players.Add(player);

    public void Win()
    {
        PointsEarned += 3;
        foreach (IPlayer player in Players)
        {
            player.IncreaseRating();
        }
    }

    public void Lose()
    {
        foreach (IPlayer player in Players)
        {
            player.DecreaseRating();
        }
    }

    public void Draw()
    {
        PointsEarned += 1;
        players.First(p => p.GetType().Name == "Goalkeeper").IncreaseRating();
    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();

        string players = "none";
        if (Players.Count > 0)
        {
            players = string.Join(", ", Players);
        }
        
        sb.AppendLine($"Team: {Name} Points: {PointsEarned}");
        sb.AppendLine($"--Overall rating: {OverallRating}");
        sb.AppendLine($"--Players: {players}");

        return sb.ToString().Trim();
    }
}