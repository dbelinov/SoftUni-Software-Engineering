﻿using System;
using NUnit.Framework;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void Does_DummyLoseHealth_WhenAttacked()
        {
            Dummy dummy = new(10, 10);
            Axe axe = new(1, 20);

            axe.Attack(dummy);

            Assert.AreEqual(9, dummy.Health, "Dummy has to lose health");
        }

        [Test]
        public void Does_DeadDummy_ThrowError_WhenAttacked()
        {
            Axe axe = new(10, 10);
            Dummy dummy = new(0, 10);

            Assert.Throws<InvalidOperationException>(() => dummy.TakeAttack(10), "Can't attack dead dummy");
        }

        [Test]
        public void Does_DeadDummy_GiveXp()
        {
            Dummy dummy = new(20, 10);

            Assert.Throws<InvalidOperationException>(() => dummy.GiveExperience(), "Target is not dead");
        }

        [Test]
        public void Does_IsDead_ReturnTrue_When_DummyDead()
        {
            Dummy dummy = new Dummy(0, 10);

            Assert.IsTrue(dummy.IsDead());
        }
    }
}