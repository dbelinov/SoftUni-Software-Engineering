namespace FoodShortage.Engine.Interfaces;

public interface IEngine
{
    void Run();
}