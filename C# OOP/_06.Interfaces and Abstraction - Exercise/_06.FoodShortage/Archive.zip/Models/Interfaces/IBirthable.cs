namespace FoodShortage.Models.Interfaces;

public interface IBirthable
{
    string Birthdate { get; }
}