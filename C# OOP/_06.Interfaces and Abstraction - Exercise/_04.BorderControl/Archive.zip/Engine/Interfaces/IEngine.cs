namespace BorderControl.Engine.Interfaces;

public interface IEngine
{
    void Run();
}