namespace Telephony.Models.Interfaces;

public interface IBrowsable
{
    string Browse(string url);
}