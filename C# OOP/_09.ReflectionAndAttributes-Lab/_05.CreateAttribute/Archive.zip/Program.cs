﻿namespace AuthorProblem;

[Author("Victor")]
public class StartUp
{
    [Author("Mitko")]
    public static void Main()
    {
        Console.WriteLine();
    }
}