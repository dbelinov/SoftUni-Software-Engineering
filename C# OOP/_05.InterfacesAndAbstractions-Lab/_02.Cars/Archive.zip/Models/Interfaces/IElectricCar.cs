namespace Cars.Models.Interfaces;

public interface IElectricCar
{
    int Battery { get; }
}