namespace Shapes.Models.Interfaces;

public interface IDrawable
{
    void Draw();
}